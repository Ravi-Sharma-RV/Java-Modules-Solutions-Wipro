import java.util.Scanner;
import java.util.*;

class Cmini2{
	public static void main(String args[]){

		ArrayList<String> list=new ArrayList<String>();

		list.add("wipro");
		list.add("technologies");
		list.add("java");
		list.add("modules");
		list.add("collections");

		Scanner sc=new Scanner(System.in);

		System.out.println("1.Insert");
		System.out.println("2.Search");
		System.out.println("3.Delete");
		System.out.println("4.Display");
		System.out.println("5.Exit");

		System.out.println("Enter your choice");

		int choice=sc.nextInt();

		switch(choice){

			case 1:
			System.out.println("Enter the element to insert");
			String s=sc.nextLine();
			s=sc.nextLine();
			list.add(s);
			System.out.println("Inserted Successfully");
			break;

			case 2:
			System.out.println("Enter the element to Search");
			String r=sc.nextLine();
			r=sc.nextLine();
			if(list.contains(r)){
				System.out.println("Entered item is present");
			}
			else{
				System.out.println("Entered item is not present");
			}
			break;

			case 3:
			System.out.println("Enter the element to delete");
			String m=sc.nextLine();
			m=sc.nextLine();
			if(list.contains(m)){
				list.remove(m);
				System.out.println("Item deleted Successfully");
			}
			else{
				System.out.println("The item you want to delete is not present");
			}
			break;

			case 4:
			System.out.println("Display of all present items");
			System.out.println(list);
			break;

			case 5:
			System.out.println("Exit");
			break;

			default:
			System.out.println("Wrong choice Entered");
		}


	}
}