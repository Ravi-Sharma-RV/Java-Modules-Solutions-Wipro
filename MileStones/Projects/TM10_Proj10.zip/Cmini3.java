import java.util.*;

class Cmini3{
	public static void main(String args[]){
		
		Scanner sc=new Scanner(System.in);

		ArrayList<String> list=new ArrayList<String>();

		for(int i=0;i<8;i++){

			System.out.println("Enter a card");
			String s=sc.nextLine();
			list.add(s);
		}

		for(int j=0;j<list.size()-1;j++){
			int m=0;
			for(int x=j+1;x<list.size()-1;){
				if(list.get(j).charAt(m)==list.get(x).charAt(m)){
					list.remove(list.get(x));
				}
				else{
					x++;
				}
			}
		}

		System.out.println(list.size()+" Symbols gathered in 8 cards");

		System.out.println("Cards in the Set are::");

		TreeSet<String> ans=new TreeSet<String>();

		for(int d=0;d<list.size();d++){
			ans.add(list.get(d));
		}

		System.out.println(ans);
	}
}