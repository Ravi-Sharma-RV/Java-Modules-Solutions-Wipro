import java.util.*;
import java.lang.*;

class Cmini4{
	public static void main(String args[]){

		Scanner sc=new Scanner(System.in);

		int ne;

		System.out.println("Enter number of cards");
		ne=sc.nextInt();

		ArrayList<String> key=new ArrayList<String>();
		ArrayList<Integer> value=new ArrayList<Integer>();

		for(int ie=0;ie<ne;ie++){
			System.out.println("Enter card "+(ie+1));
			String ke;
			int ve;
			ke=sc.next();
			key.add(ke);
			ve=sc.nextInt();
			value.add(ve);
		}
		
		HashMap<ArrayList<String>,ArrayList<Integer>> map=new HashMap<ArrayList<String>,ArrayList<Integer>>();

		map.put(key,value);

		ArrayList<String> symbols=new ArrayList<String>();
		ArrayList<Integer> numbers=new ArrayList<Integer>();
		
		for(Map.Entry<ArrayList<String>, ArrayList<Integer>> me : map.entrySet()){
			ArrayList<String> ukey=me.getKey();
			ArrayList<Integer> uvalue=me.getValue();
			for(int id=0;id<ukey.size();id++){
			symbols.add(ukey.get(id));
			numbers.add(uvalue.get(id));
			}

		}

		TreeSet<String> dist=new TreeSet<String>();
		dist.addAll(symbols);

		System.out.println("Distinct Symbols are:");
		System.out.println(dist);

		ArrayList<String> arr=new ArrayList<String>();
		ArrayList<Integer> brr=new ArrayList<Integer>();

		for(int a=0;a<symbols.size();a++){
			if(symbols.get(a).equals("a")){
				arr.add(symbols.get(a));
				brr.add(numbers.get(a));
			}
		}

		for(int b=0;b<symbols.size();b++){
			if(symbols.get(b).equals("b")){
				arr.add(symbols.get(b));
				brr.add(numbers.get(b));
			}
		}

		for(int c=0;c<symbols.size();c++){
			if(symbols.get(c).equals("c")){
				arr.add(symbols.get(c));
				brr.add(numbers.get(c));
			}
		}

		for(int d=0;d<symbols.size();d++){
			if(symbols.get(d).equals("d")){
				arr.add(symbols.get(d));
				brr.add(numbers.get(d));
			}
		}

		for(int e=0;e<symbols.size();e++){
			if(symbols.get(e).equals("e")){
				arr.add(symbols.get(e));
				brr.add(numbers.get(e));
			}
		}

		for(int f=0;f<symbols.size();f++){
			if(symbols.get(f).equals("f")){
				arr.add(symbols.get(f));
				brr.add(numbers.get(f));
			}
		}

		for(int g=0;g<symbols.size();g++){
			if(symbols.get(g).equals("g")){
				arr.add(symbols.get(g));
				brr.add(numbers.get(g));
			}
		}

		for(int h=0;h<symbols.size();h++){
			if(symbols.get(h).equals("h")){
				arr.add(symbols.get(h));
				brr.add(numbers.get(h));
			}
		}

		for(int i=0;i<symbols.size();i++){
			if(symbols.get(i).equals("i")){
				arr.add(symbols.get(i));
				brr.add(numbers.get(i));
			}
		}

		for(int j=0;j<symbols.size();j++){
			if(symbols.get(j).equals("j")){
				arr.add(symbols.get(j));
				brr.add(numbers.get(j));
			}
		}

		for(int k=0;k<symbols.size();k++){
			if(symbols.get(k).equals("k")){
				arr.add(symbols.get(k));
				brr.add(numbers.get(k));
			}
		}

		for(int l=0;l<symbols.size();l++){
			if(symbols.get(l).equals("l")){
				arr.add(symbols.get(l));
				brr.add(numbers.get(l));
			}
		}

		for(int m=0;m<symbols.size();m++){
			if(symbols.get(m).equals("m")){
				arr.add(symbols.get(m));
				brr.add(numbers.get(m));
			}
		}

		for(int n=0;n<symbols.size();n++){
			if(symbols.get(n).equals("n")){
				arr.add(symbols.get(n));
				brr.add(numbers.get(n));
			}
		}

		for(int o=0;o<symbols.size();o++){
			if(symbols.get(o).equals("o")){
				arr.add(symbols.get(o));
				brr.add(numbers.get(o));
			}
		}

		for(int p=0;p<symbols.size();p++){
			if(symbols.get(p).equals("p")){
				arr.add(symbols.get(p));
				brr.add(numbers.get(p));
			}
		}

		for(int q=0;q<symbols.size();q++){
			if(symbols.get(q).equals("q")){
				arr.add(symbols.get(q));
				brr.add(numbers.get(q));
			}
		}

		for(int r=0;r<symbols.size();r++){
			if(symbols.get(r).equals("r")){
				arr.add(symbols.get(r));
				brr.add(numbers.get(r));
			}
		}

		for(int s=0;s<symbols.size();s++){
			if(symbols.get(s).equals("s")){
				arr.add(symbols.get(s));
				brr.add(numbers.get(s));
			}
		}

		for(int t=0;t<symbols.size();t++){
			if(symbols.get(t).equals("t")){
				arr.add(symbols.get(t));
				brr.add(numbers.get(t));
			}
		}

		for(int u=0;u<symbols.size();u++){
			if(symbols.get(u).equals("u")){
				arr.add(symbols.get(u));
				brr.add(numbers.get(u));
			}
		}

		for(int v=0;v<symbols.size();v++){
			if(symbols.get(v).equals("v")){
				arr.add(symbols.get(v));
				brr.add(numbers.get(v));
			}
		}

		for(int w=0;w<symbols.size();w++){
			if(symbols.get(w).equals("w")){
				arr.add(symbols.get(w));
				brr.add(numbers.get(w));
			}
		}

		for(int x=0;x<symbols.size();x++){
			if(symbols.get(x).equals("x")){
				arr.add(symbols.get(x));
				brr.add(numbers.get(x));
			}
		}

		for(int y=0;y<symbols.size();y++){
			if(symbols.get(y).equals("y")){
				arr.add(symbols.get(y));
				brr.add(numbers.get(y));
			}
		}

		for(int z=0;z<symbols.size();z++){
			if(symbols.get(z).equals("z")){
				arr.add(symbols.get(z));
				brr.add(numbers.get(z));
			}
		}

		for(int b=0;b<symbols.size();b++){
			if(symbols.get(b).equals("b")){
				arr.add(symbols.get(b));
				brr.add(numbers.get(b));
			}
		}
		System.out.println("Cards in "+arr.get(0)+" Symbol");
			
		for(int list=0;list<arr.size()-1;list++){
			
			if(arr.get(list).equals(arr.get(list+1))){
				
				System.out.print(arr.get(list));
				System.out.print(" ");
				System.out.print(brr.get(list));
				System.out.print("\n");
				
			}
			else{
				System.out.print(arr.get(list));
				System.out.print(" ");
				System.out.print(brr.get(list));
				System.out.print("\n");
				
				System.out.print("Cards in "+arr.get(list+1)+" Symbol");
				System.out.print("\n");
				
			}

		}
	}
}