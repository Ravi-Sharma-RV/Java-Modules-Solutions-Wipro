import java.util.*;

class Cmini6{

	public static void main(String[] args){

		Scanner sc=new Scanner(System.in);

		ArrayList<String> ans=new ArrayList<String>();

		System.out.println("Enter String 1");
		String s1=sc.next();
		System.out.println("Enter String 2");
		String s2=sc.next();

		String ans1="";
		

		for(int i=1;i<s1.length();i=i+2){
 			
 			ans1+=s2;
 			ans1+=s1.charAt(i);
		}
		


		String ans2="";
		String s3;
		int count=0;
		StringBuilder s = new StringBuilder(s2);
		for(int i=0;i<s1.length()-1;i++){
			if(s1.substring(i,(i+2)).equals(s2)){
				count++;
			}
		}
			if(count>1){
				for(int j=s1.length()-1;j>s2.length()-1;j--){
					if(s1.substring(j-s2.length()+1,j+1).equals(s2)){
						s3=(s.reverse()).toString();
						ans2+=s1.substring(0,j-s2.length()+1);
						ans2+=s3;
						if(j>s1.length()-1)
							ans2+=s1.substring(j+1,s1.length()-1);
						break;
					}
				}
			}
			else{
				ans2=s1+s2;
			}
		
		



			String ans3= "";
			StringBuffer sb=new StringBuffer(s1);
			int flag=0;
			for(int i=0;i<s1.length()-1;i++){
				if(s1.substring(i,(i+2)).equals(s2)){
				flag++;
				}
			}

			if(flag>1){
				for(int k=0;k<s1.length();k++){
					if(s1.substring(k,(k+2)).equals(s2)){
						sb=sb.delete(k,(k+2));
						ans3+=sb;
						break;
					}
				}
			}

			

			String ans4="";
			String s21="";
			String s22="";
			if(s2.length()%2==0){
				s21+=s2.substring(0,s2.length()/2);
				s22+=s2.substring(s2.length()/2,s2.length());
				ans4+=s21+s1;
				ans4+=s22;
			}
			else{
				s21+=s2.substring(0,(s2.length()/2)+1);
				s22+=s2.substring((s2.length()/2)+1,s2.length());
				ans4+=s21+s1+s22;
			}



			String ans5="";
			StringBuilder bb=new StringBuilder(s1);

			for(int a=0;a<s2.length();a++){
				for(int b=0;b<s1.length();b++){
					if(s2.charAt(a)==s1.charAt(b)){
						bb.replace(b,(b+1),"*");
						
					}
				}
			}
			ans5=bb.toString();
			

			ans.add(ans1);
			ans.add(ans2);
			ans.add(ans3);
			ans.add(ans4);
			ans.add(ans5);

			System.out.println(ans);

	}
}