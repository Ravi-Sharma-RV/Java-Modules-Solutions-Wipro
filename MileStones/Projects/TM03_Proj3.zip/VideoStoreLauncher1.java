import java.util.Scanner;
class Video
{
	String title;
	boolean flag,flag1;
	double rating;
	
	
	boolean beingChecked(boolean c)
	{
		this.flag=c;
		return flag;
		
	}
	
	boolean beingReturned(boolean r)
	{
		this.flag1=r;
		return flag1;
		
	}
	
	double recieveRating1(double rate)
	{
		this.rating=rate;
		return rating;
		
	}
	
	String storeTitle(String title1)
	{
		this.title=title1;
		return title;
	}
	
}

class VideoStore
{
	Video[] v = new Video[10];
	static int i=0;
	int k,l;
	
	
	void addVideo(String title1)
	{
		v[i]= new Video();
		v[i].storeTitle(title1);
		v[i].beingChecked(false);
		v[i].beingReturned(true);
		i=i+1;
		System.out.println("________________________________________________________________________________");
		System.out.print(title1+" successfully added to inventory \n\n");
		System.out.println("________________________________________________________________________________");
	}
	
	void checkOut(String title1)
	{
		for(int k=0;k<i;k++)
		{
			if(title1.equals(v[k].title))
			{
				l=k;
				
			}
			
			
			
		}
	
		if(!title1.equals(v[l].title))
		{
				System.out.println("________________________________________________________________________________");
				System.out.println(title1+" not Available ");
				System.out.println("________________________________________________________________________________");
				
		}
		
		else if(v[l].flag==false)
		{
			System.out.println("________________________________________________________________________________");
			System.out.println(v[l].title+" successfully checked out \n\nThanks for buying "+v[l].title);
			System.out.println("________________________________________________________________________________");
			v[l].beingChecked(true);
			v[l].beingReturned(false);
			
		}
		/*else
		{
			System.out.println("________________________________________________________________________________");
			System.out.println(title1+" not Available ");
			System.out.println("________________________________________________________________________________");
		}
		*/
	}
	
	
	void returnVideo(String title1)
	{
		for(k=0;k<i;k++)
		{
			if(title1.equals(v[k].title))
			{
				l=k;
				
			}
			
		}
		
		if(!title1.equals(v[l].title))
		{
			System.out.println("________________________________________________________________________________");
			System.out.println("No "+title1+" was rented");
			System.out.println("________________________________________________________________________________");
			
		}
		
		else if(v[l].flag1==false)
		{
			System.out.println("________________________________________________________________________________");
			System.out.println("Thanks please do visit again!!!!");
			System.out.println("________________________________________________________________________________");
			v[l].beingReturned(true);
			v[l].beingChecked(false);
			
		}
		else
		{
			System.out.println("________________________________________________________________________________");
			System.out.println("No "+title1+" was rented");
			System.out.println("________________________________________________________________________________");
		}
		
	}
	
	void receiveRating(String title1,double rating)
	{
		for(k=0;k<i;k++)
		{
			if(title1.equals(v[k].title))
			{
				l=k;
			}
			
		}
		
		if(!title1.equals(v[l].title))
		{
			//System.out.println("________________________________________________________________________________");
			System.out.println("No "+title1+" was found");
			System.out.println("________________________________________________________________________________");
		}
		else
		{
		v[l].recieveRating1(rating);
		System.out.println(title1+" rated successfully");
		System.out.println("________________________________________________________________________________");
		}
	}
	
	
	void listInventory()
	{
		System.out.println("________________________________________________________________________________");
		System.out.print("                                 INVENTORY LIST                                 ");
		System.out.print("________________________________________________________________________________");
		System.out.print("\n");
		int z;
		for(int j=0;j<i;j++)
		{
			if(v[j].flag1==true&&v[j].flag==false)
			{
				z=j;
				z++;
				System.out.println(z+"-"+v[j].title+"  Rating-"+v[j].rating);
				System.out.println();
			}
			
		}
		System.out.println("________________________________________________________________________________");
	}
}
	
class VideoStoreLauncher1
{
	public static void main(String[] args)
	{
		VideoStore vl = new VideoStore();
		Scanner s = new Scanner(System.in);
		System.out.println("\n");
		System.out.println("________________________________________________________________________________");
		System.out.println("	    	  WELCOME TO VIDEO RENTAL INVENTORY SYSTEM 	");
		System.out.println("________________________________________________________________________________");
		System.out.println("					MENU");
			
		int n=0;
			
		while(n!=6)
		{
			System.out.print("1.Add Video \n\n2.Rent Video \n\n3.Enter rating \n\n4.Return Video \n\n5.List Inventory \n\n6.EXIT\n");
			System.out.println("________________________________________________________________________________");
			System.out.print("Enter your choice:");
			n = s.nextInt();
			System.out.println("________________________________________________________________________________");
			
			switch(n)
			{
				case 1:
				System.out.print("\n\nEnter name of video to add :");
				String name;
				s.nextLine();
				name=s.nextLine();
				vl.addVideo(name);
				break;
				
				case 2:
				System.out.print("\n\nEnter name of video to rent :");
				String name1;
				s.nextLine();
				name1 = s.nextLine();
				vl.checkOut(name1);
				break;
				
				case 3:
				System.out.print("\n\nEnter name of video for rating:");
				String name3;
				s.nextLine();
				name3 = s.nextLine();
				System.out.print("\n\nEnter rating:");
				double rat = s.nextDouble();
				System.out.println("________________________________________________________________________________");
				vl.receiveRating(name3,rat);
				break;
				
				
				
				case 4:
				System.out.print("\n\nEnter name of video to return :");
				String name2;
				s.nextLine();
				name2 = s.nextLine();
				vl.returnVideo(name2);
				break;
				
				case 5:
				vl.listInventory();
				break;
				
			}
		}
	}
}

			
			
			
		
	
	
	