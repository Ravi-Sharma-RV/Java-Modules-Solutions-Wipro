import java.io.*;
class DeSerialize1
{
	
	public static void main(String[] args) throws IOException{
	
	try{
	
		
		

		FileInputStream fi = new FileInputStream("C:\\Users\\student.C-304-PC\\Desktop\\OutObject.txt");
		ObjectInputStream oi = new ObjectInputStream(fi);
		Employee emp;
		emp=(Employee)oi.readObject();
		

		System.out.println("Name:"+emp.getName());
		System.out.println("Date Of Birth:"+emp.getDob());
		System.out.println("Department:"+emp.getDepartment());
		System.out.println("Designation:"+emp.getDesignation());
		System.out.println("Salary:"+emp.getSalary());
		
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
}