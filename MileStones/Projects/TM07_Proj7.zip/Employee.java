import java.io.*;
class Employee implements Serializable 
{
	String name;
	String dob;
	String department;
	String designation;
	double salary;
	

	public void setName(String name)
	{
		this.name=name;
	}


	public void setDob(String dob)
	{
		this.dob=dob;
	}


	public void setDepartment(String department)
	{
		this.department=department;
	}


	public void setDesignation(String designation)
	{
		this.designation=designation;
	}


	public void setSalary(double salary)
	{
		this.salary=salary;
	}







	public String getName()
	{
		return name;
	}


	public String getDob()
	{
		return dob;
	}


	public String getDepartment()
	{
		return department;
	}


	public String getDesignation()
	{
		return designation;
	}


	public double getSalary()
	{
		return salary;
	}


}



	






	