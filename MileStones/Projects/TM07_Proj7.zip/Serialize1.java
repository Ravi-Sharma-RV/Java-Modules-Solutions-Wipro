import java.io.*;
class Serialize1
{
	public static void main(String[] args) throws IOException
	{
		Employee emp = new Employee();
		emp.setName("Munendra");
		emp.setDob("16 nov 1196");
		emp.setDepartment("scse");
		emp.setDesignation("student");
		emp.setSalary(12000.789);

		FileOutputStream fo = new FileOutputStream("C:\\Users\\student.C-304-PC\\Desktop\\OutObject.txt");
		ObjectOutputStream oo = new ObjectOutputStream(fo);
		oo.writeObject(emp);
		oo.flush();
	}
}
		